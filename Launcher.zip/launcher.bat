@echo off
"j8\bin\java.exe" -jar Updater.jar